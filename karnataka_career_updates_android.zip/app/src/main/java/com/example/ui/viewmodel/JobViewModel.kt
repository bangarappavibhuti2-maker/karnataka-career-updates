package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppLanguage
import com.example.data.model.CategoryType
import com.example.data.model.JobItem
import com.example.data.remote.BloggerBlogInfo
import com.example.data.repository.JobRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class JobViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = JobRepository(application)

    val language: StateFlow<AppLanguage> = repository.language
    val bloggerUrl: StateFlow<String> = repository.bloggerUrl
    val blogInfo: StateFlow<BloggerBlogInfo?> = repository.blogInfo
    val feedJobs: StateFlow<List<JobItem>> = repository.feedJobs
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val errorMessage: StateFlow<String?> = repository.errorMessage

    val savedJobs: StateFlow<List<JobItem>> = repository.savedJobs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow(CategoryType.ALL)

    private val _selectedJobDetail = MutableStateFlow<JobItem?>(null)
    val selectedJobDetail: StateFlow<JobItem?> = _selectedJobDetail.asStateFlow()

    private val _showConnectDialog = MutableStateFlow(false)
    val showConnectDialog: StateFlow<Boolean> = _showConnectDialog.asStateFlow()

    val searchResults: StateFlow<List<JobItem>> = combine(
        feedJobs,
        searchQuery,
        selectedCategory
    ) { jobs, query, category ->
        val filteredByCategory = if (category == CategoryType.ALL) {
            jobs
        } else {
            jobs.filter { it.category == category }
        }

        if (query.isBlank()) {
            filteredByCategory
        } else {
            val q = query.trim().lowercase()
            filteredByCategory.filter { item ->
                item.title.lowercase().contains(q) ||
                item.summary.lowercase().contains(q) ||
                item.tags.any { it.lowercase().contains(q) }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Automatically check if Blogger URL is already configured, fetch posts
        viewModelScope.launch {
            if (bloggerUrl.value.isNotBlank()) {
                repository.refreshFeed()
            } else {
                // If not configured, show connect dialog initially so user is asked for Blogger URL first!
                _showConnectDialog.value = true
            }
        }
    }

    fun setLanguage(lang: AppLanguage) {
        repository.setLanguage(lang)
    }

    fun toggleLanguage() {
        val next = if (language.value == AppLanguage.ENGLISH) AppLanguage.KANNADA else AppLanguage.ENGLISH
        repository.setLanguage(next)
    }

    fun openConnectDialog() {
        _showConnectDialog.value = true
    }

    fun closeConnectDialog() {
        _showConnectDialog.value = false
    }

    fun connectBlogger(url: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        viewModelScope.launch {
            val result = repository.saveBloggerUrl(url)
            if (result.isSuccess) {
                _showConnectDialog.value = false
                onComplete?.invoke(true, null)
            } else {
                onComplete?.invoke(false, result.exceptionOrNull()?.message ?: "Connection failed")
            }
        }
    }

    fun disconnectBlogger() {
        repository.disconnectBlogger()
        _showConnectDialog.value = true
    }

    fun refresh() {
        viewModelScope.launch {
            repository.refreshFeed()
        }
    }

    fun toggleSaveJob(job: JobItem) {
        viewModelScope.launch {
            repository.toggleSaveJob(job)
        }
    }

    fun deleteSavedJob(jobId: String) {
        viewModelScope.launch {
            repository.deleteSavedJob(jobId)
        }
    }

    fun selectJobDetail(job: JobItem) {
        _selectedJobDetail.value = job
    }

    fun clearJobDetail() {
        _selectedJobDetail.value = null
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setSelectedCategory(category: CategoryType) {
        selectedCategory.value = category
    }
}
