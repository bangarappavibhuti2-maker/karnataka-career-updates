package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = KarnatakaBlueLight,
    onPrimary = CleanWhite,
    primaryContainer = KarnatakaNavyDarkTheme,
    onPrimaryContainer = CleanWhite,
    secondary = KarnatakaYellow,
    onSecondary = TextDarkPrimary,
    secondaryContainer = KarnatakaOnYellowContainer,
    onSecondaryContainer = KarnatakaYellowContainer,
    background = BackgroundDark,
    surface = SurfaceDark,
    onBackground = CleanWhite,
    onSurface = CleanWhite,
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF334155)
)

private val LightColorScheme = lightColorScheme(
    primary = KarnatakaNavyBlue,
    onPrimary = CleanWhite,
    primaryContainer = KarnatakaBlueContainer,
    onPrimaryContainer = KarnatakaOnBlueContainer,
    secondary = KarnatakaYellowAmber,
    onSecondary = TextDarkPrimary,
    secondaryContainer = KarnatakaYellowContainer,
    onSecondaryContainer = KarnatakaOnYellowContainer,
    tertiary = KarnatakaRoyalBlue,
    background = CleanOffWhite,
    surface = CleanWhite,
    onBackground = TextDarkPrimary,
    onSurface = TextDarkPrimary,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = TextDarkSecondary,
    outline = SlateCardBorder
)

@Composable
fun KarnatakaCareerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
