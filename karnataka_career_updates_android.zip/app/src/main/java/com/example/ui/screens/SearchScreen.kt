package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.JobItem
import com.example.ui.components.JobCard
import com.example.ui.theme.CleanWhite
import com.example.ui.theme.KarnatakaNavyBlue
import com.example.ui.theme.KarnatakaYellow
import com.example.ui.theme.KarnatakaYellowAmber
import com.example.ui.theme.TextDarkPrimary

@Composable
fun SearchScreen(
    searchQuery: String,
    searchResults: List<JobItem>,
    savedJobs: List<JobItem>,
    language: AppLanguage,
    onQueryChange: (String) -> Unit,
    onJobClick: (JobItem) -> Unit,
    onToggleSave: (JobItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current

    val popularTags = listOf(
        "KPSC" to "ಕೆ.ಪಿ.ಎಸ್.ಸಿ",
        "Police" to "ಪೊಲೀಸ್",
        "KEA" to "ಕೆ.ಇ.ಎ",
        "FDA/SDA" to "ಎಫ್.ಡಿ.ಎ/ಎಸ್.ಡಿ.ಎ",
        "Teachers" to "ಶಿಕ್ಷಕರ ಹುದ್ದೆ",
        "Admit Card" to "ಪ್ರವೇಶ ಪತ್ರ",
        "Result" to "ಫಲಿತಾಂಶ"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("search_screen")
    ) {
        // Search Input Card
        Surface(
            color = CleanWhite,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input_field"),
                    placeholder = {
                        Text(AppStrings.searchPlaceholder(language))
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = KarnatakaNavyBlue
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onQueryChange("") },
                                modifier = Modifier.testTag("clear_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = TextDarkPrimary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = KarnatakaNavyBlue,
                        focusedLabelColor = KarnatakaNavyBlue,
                        cursorColor = KarnatakaNavyBlue
                    ),
                    shape = RoundedCornerShape(16.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Popular Keywords
                Text(
                    text = if (language == AppLanguage.KANNADA) "ಜನಪ್ರಿಯ ಹುಡುಕಾಟಗಳು:" else "Popular Keywords:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(popularTags) { (en, kn) ->
                        val label = if (language == AppLanguage.KANNADA) kn else en
                        Box(
                            modifier = Modifier
                                .border(1.dp, KarnatakaYellowAmber, RoundedCornerShape(20.dp))
                                .background(KarnatakaYellow.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                                .clickable {
                                    onQueryChange(en)
                                    focusManager.clearFocus()
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("keyword_chip_$en")
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Search Results List
        if (searchQuery.isNotEmpty() && searchResults.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CleanWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(KarnatakaYellow.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = KarnatakaNavyBlue,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = AppStrings.noResultsFound(language),
                            style = MaterialTheme.typography.titleMedium,
                            color = KarnatakaNavyBlue,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (language == AppLanguage.KANNADA)
                                "ದಯವಿಟ್ಟು ಬೇರೆ ಕೀವರ್ಡ್ ಬಳಸಿ ಹುಡುಕಿ (ಉದಾ: KPSC, KEA, ಪರೀಕ್ಷೆ)."
                            else
                                "Try searching with broader keywords like KPSC, Police, or Result.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (searchQuery.isNotEmpty()) {
                    item {
                        Text(
                            text = "${searchResults.size} " + if (language == AppLanguage.KANNADA) "ಫಲಿತಾಂಶಗಳು ಸಿಕ್ಕಿವೆ" else "results found",
                            style = MaterialTheme.typography.labelLarge,
                            color = KarnatakaNavyBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                items(searchResults, key = { it.id }) { job ->
                    val isSaved = savedJobs.any { it.id == job.id }
                    JobCard(
                        job = job,
                        isSaved = isSaved,
                        language = language,
                        onJobClick = onJobClick,
                        onToggleSave = onToggleSave
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
