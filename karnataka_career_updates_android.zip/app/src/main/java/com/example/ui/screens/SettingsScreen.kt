package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.remote.BloggerBlogInfo
import com.example.ui.theme.CleanWhite
import com.example.ui.theme.KarnatakaNavyBlue
import com.example.ui.theme.KarnatakaYellow
import com.example.ui.theme.KarnatakaYellowAmber
import com.example.ui.theme.TextDarkPrimary

@Composable
fun SettingsScreen(
    bloggerUrl: String,
    blogInfo: BloggerBlogInfo?,
    language: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    onOpenConnectDialog: () -> Unit,
    onDisconnectBlogger: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBloggerConnected = bloggerUrl.isNotBlank()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section 1: Blogger Website Connection
        item {
            Text(
                text = if (language == AppLanguage.KANNADA) "ಬ್ಲಾಗರ್ ವೆಬ್‌ಸೈಟ್ ಸಂಪರ್ಕ" else "Blogger Connection",
                style = MaterialTheme.typography.titleLarge,
                color = KarnatakaNavyBlue,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CleanWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    if (isBloggerConnected) KarnatakaNavyBlue else KarnatakaYellow.copy(alpha = 0.3f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isBloggerConnected) Icons.Default.CheckCircle else Icons.Default.Link,
                                contentDescription = null,
                                tint = if (isBloggerConnected) KarnatakaYellow else KarnatakaNavyBlue,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBloggerConnected) {
                                    blogInfo?.title ?: "Connected Blogger Blog"
                                } else {
                                    AppStrings.notConnectedStatus(language)
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isBloggerConnected) bloggerUrl else AppStrings.bloggerUrlHint(language),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isBloggerConnected && blogInfo != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(KarnatakaYellow.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (language == AppLanguage.KANNADA) "ಒಟ್ಟು ಪೋಸ್ಟ್‌ಗಳು:" else "Total Blog Posts:",
                                style = MaterialTheme.typography.labelMedium,
                                color = KarnatakaNavyBlue
                            )
                            Text(
                                text = "${blogInfo.totalPosts}",
                                style = MaterialTheme.typography.labelLarge,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onOpenConnectDialog,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("settings_change_blogger_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = KarnatakaNavyBlue,
                                contentColor = CleanWhite
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (isBloggerConnected) AppStrings.changeUrlButton(language) else AppStrings.connectButton(language),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (isBloggerConnected) {
                            OutlinedButton(
                                onClick = onDisconnectBlogger,
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("settings_disconnect_blogger_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Disconnect",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (language == AppLanguage.KANNADA) "ತೆಗೆದುಹಾಕಿ" else "Disconnect",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Language Selection (Kannada & English)
        item {
            Text(
                text = if (language == AppLanguage.KANNADA) "ಭಾಷೆ ಆಯ್ಕೆ / Language Selection" else "Language Selection",
                style = MaterialTheme.typography.titleLarge,
                color = KarnatakaNavyBlue,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CleanWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // English Option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onLanguageChange(AppLanguage.ENGLISH) }
                            .padding(12.dp)
                            .testTag("language_option_english"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = language == AppLanguage.ENGLISH,
                            onClick = { onLanguageChange(AppLanguage.ENGLISH) },
                            colors = RadioButtonDefaults.colors(selectedColor = KarnatakaNavyBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "English",
                                style = MaterialTheme.typography.titleMedium,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Use English for all menu items and labels",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Kannada Option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onLanguageChange(AppLanguage.KANNADA) }
                            .padding(12.dp)
                            .testTag("language_option_kannada"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = language == AppLanguage.KANNADA,
                            onClick = { onLanguageChange(AppLanguage.KANNADA) },
                            colors = RadioButtonDefaults.colors(selectedColor = KarnatakaNavyBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "ಕನ್ನಡ (Kannada)",
                                style = MaterialTheme.typography.titleMedium,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "ಎಲ್ಲಾ ಮೆನು ಮತ್ತು ಬಟನ್‌ಗಳನ್ನು ಕನ್ನಡದಲ್ಲಿ ವೀಕ್ಷಿಸಿ",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Section 3: Authenticity & Trust Statement
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CleanWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, KarnatakaYellow, RoundedCornerShape(20.dp))
                        .padding(20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = KarnatakaNavyBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (language == AppLanguage.KANNADA) "ನೈಜ ಮಾಹಿತಿ ಭರವಸೆ" else "Authenticity Guarantee",
                            style = MaterialTheme.typography.titleMedium,
                            color = KarnatakaNavyBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (language == AppLanguage.KANNADA)
                            "ನಾವು ಎಂದಿಗೂ ಯಾವುದೇ ಸರ್ಕಾರಿ ಉದ್ಯೋಗ ಪ್ರಕಟಣೆಗಳು, ಪ್ರವೇಶ ಪತ್ರಗಳು ಅಥವಾ ಫಲಿತಾಂಶಗಳನ್ನು ಕೃತಕವಾಗಿ ಅಥವಾ ನಕಲಿಯಾಗಿ ಸೃಷ್ಟಿಸುವುದಿಲ್ಲ. ನಿಮ್ಮ ಬ್ಲಾಗರ್ ಸೈಟ್‌ನ ನೈಜ ಪೋಸ್ಟ್‌ಗಳನ್ನು ಮಾತ್ರ ನೇರವಾಗಿ ತೋರಿಸಲಾಗುತ್ತದೆ."
                        else
                            "This application connects strictly to your designated Blogger feed. In strict compliance with guidelines, we NEVER invent or hallucinate government job notifications, admit cards, or exam results.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextDarkPrimary,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Karnataka Career Updates • Version 1.0",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
