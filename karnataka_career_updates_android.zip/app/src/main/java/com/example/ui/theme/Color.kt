package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Karnataka Career Updates Palette (Blue, White, Yellow)
val KarnatakaNavyBlue = Color(0xFF0D47A1)
val KarnatakaNavyBlueDark = Color(0xFF0A2B64)
val KarnatakaRoyalBlue = Color(0xFF1565C0)
val KarnatakaBlueLight = Color(0xFF1E88E5)
val KarnatakaBlueContainer = Color(0xFFE3F2FD)
val KarnatakaOnBlueContainer = Color(0xFF0D3B66)

val KarnatakaYellow = Color(0xFFFFB300)
val KarnatakaYellowAmber = Color(0xFFF59E0B)
val KarnatakaYellowDark = Color(0xFFD97706)
val KarnatakaYellowContainer = Color(0xFFFEF3C7)
val KarnatakaOnYellowContainer = Color(0xFF78350F)

val CleanWhite = Color(0xFFFFFFFF)
val CleanOffWhite = Color(0xFFF8FAFC)
val SlateCardBorder = Color(0xFFE2E8F0)
val SlateSurfaceVariant = Color(0xFFF1F5F9)
val TextDarkPrimary = Color(0xFF0F172A)
val TextDarkSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)

// Dark theme colors
val KarnatakaNavyDarkTheme = Color(0xFF1E3A8A)
val BackgroundDark = Color(0xFF0B132B)
val SurfaceDark = Color(0xFF1C2541)
