package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.CategoryType
import com.example.data.model.JobItem
import com.example.data.remote.BloggerBlogInfo
import com.example.ui.components.EmptyJobsView
import com.example.ui.components.JobCard
import com.example.ui.components.LargeCategoryButton
import com.example.ui.theme.CleanWhite
import com.example.ui.theme.KarnatakaNavyBlue
import com.example.ui.theme.KarnatakaNavyBlueDark
import com.example.ui.theme.KarnatakaRoyalBlue
import com.example.ui.theme.KarnatakaYellow
import com.example.ui.theme.KarnatakaYellowAmber
import com.example.ui.theme.TextDarkPrimary

@Composable
fun HomeScreen(
    bloggerUrl: String,
    blogInfo: BloggerBlogInfo?,
    language: AppLanguage,
    feedJobs: List<JobItem>,
    savedJobs: List<JobItem>,
    isLoading: Boolean,
    onNavigateCategory: (CategoryType) -> Unit,
    onNavigateSearch: () -> Unit,
    onNavigateSaved: () -> Unit,
    onJobClick: (JobItem) -> Unit,
    onToggleSave: (JobItem) -> Unit,
    onOpenConnectDialog: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBloggerConnected = bloggerUrl.isNotBlank()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Header Banner (Deep Blue + Yellow Crest)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_hero_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(KarnatakaNavyBlue, KarnatakaNavyBlueDark)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.appTitle(language),
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    ),
                                    color = CleanWhite
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = AppStrings.appSubtitle(language),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = KarnatakaYellow
                                )
                            }

                            // Refresh Button
                            IconButton(
                                onClick = onRefresh,
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(CleanWhite.copy(alpha = 0.15f), CircleShape)
                                    .testTag("home_refresh_button")
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = KarnatakaYellow,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Refresh",
                                        tint = CleanWhite
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Blogger Connection Status Bar (Prominent & interactive)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isBloggerConnected)
                                        CleanWhite.copy(alpha = 0.15f)
                                else
                                        KarnatakaYellow.copy(alpha = 0.95f)
                                )
                                .clickable { onOpenConnectDialog() }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .testTag("home_blogger_status_bar")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = if (isBloggerConnected) Icons.Default.CheckCircle else Icons.Default.Link,
                                        contentDescription = null,
                                        tint = if (isBloggerConnected) KarnatakaYellow else KarnatakaNavyBlue,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = if (isBloggerConnected) {
                                                blogInfo?.title ?: bloggerUrl.replace("https://", "").replace("http://", "")
                                            } else {
                                                AppStrings.connectBloggerTitle(language)
                                            },
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (isBloggerConnected) CleanWhite else KarnatakaNavyBlue,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isBloggerConnected) {
                                                if (language == AppLanguage.KANNADA) "ಸಂಪರ್ಕಗೊಂಡಿದೆ (ಬದಲಿಸಲು ಒತ್ತಿ)" else "Connected (Tap to change)"
                                            } else {
                                                if (language == AppLanguage.KANNADA) "ನಿಮ್ಮ ಬ್ಲಾಗರ್ URL ನಮೂದಿಸಿ" else "Enter Blogger URL first"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isBloggerConnected) KarnatakaYellow else TextDarkPrimary
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isBloggerConnected) CleanWhite.copy(alpha = 0.2f) else KarnatakaNavyBlue,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (isBloggerConnected) "EDIT" else "CONNECT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isBloggerConnected) CleanWhite else KarnatakaYellow,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Quick Search & Saved Shortcuts
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Search Shortcut Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onNavigateSearch() }
                        .testTag("home_quick_search_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CleanWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, KarnatakaYellow.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(KarnatakaNavyBlue, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = KarnatakaYellow,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = AppStrings.searchTab(language),
                                style = MaterialTheme.typography.titleMedium,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (language == AppLanguage.KANNADA) "ಹುದ್ದೆಗಳನ್ನು ಹುಡುಕಿ" else "Find Jobs",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Saved Jobs Shortcut Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onNavigateSaved() }
                        .testTag("home_quick_saved_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CleanWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, KarnatakaYellow.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(KarnatakaYellow, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = "Saved",
                                tint = KarnatakaNavyBlue,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = AppStrings.savedJobsTab(language),
                                style = MaterialTheme.typography.titleMedium,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${savedJobs.size} " + if (language == AppLanguage.KANNADA) "ಉಳಿಸಲಾಗಿದೆ" else "Saved",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 3. Section: Career Categories (Large Prominent Buttons)
        item {
            Text(
                text = AppStrings.quickCategoriesTitle(language),
                style = MaterialTheme.typography.titleLarge,
                color = KarnatakaNavyBlue,
                fontWeight = FontWeight.Bold
            )
        }

        // Category 1: Latest Govt Jobs
        item {
            LargeCategoryButton(
                category = CategoryType.LATEST_JOBS,
                language = language,
                count = feedJobs.count { it.category == CategoryType.LATEST_JOBS },
                onClick = { onNavigateCategory(CategoryType.LATEST_JOBS) }
            )
        }

        // Category 2: Results
        item {
            LargeCategoryButton(
                category = CategoryType.RESULTS,
                language = language,
                count = feedJobs.count { it.category == CategoryType.RESULTS },
                onClick = { onNavigateCategory(CategoryType.RESULTS) }
            )
        }

        // Category 3: Admit Cards
        item {
            LargeCategoryButton(
                category = CategoryType.ADMIT_CARDS,
                language = language,
                count = feedJobs.count { it.category == CategoryType.ADMIT_CARDS },
                onClick = { onNavigateCategory(CategoryType.ADMIT_CARDS) }
            )
        }

        // Category 4: Exam Notifications
        item {
            LargeCategoryButton(
                category = CategoryType.EXAM_NOTIFICATIONS,
                language = language,
                count = feedJobs.count { it.category == CategoryType.EXAM_NOTIFICATIONS },
                onClick = { onNavigateCategory(CategoryType.EXAM_NOTIFICATIONS) }
            )
        }

        // 4. Section: Recent Updates from Blogger
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.recentUpdatesTitle(language),
                    style = MaterialTheme.typography.titleLarge,
                    color = KarnatakaNavyBlue,
                    fontWeight = FontWeight.Bold
                )

                if (feedJobs.isNotEmpty()) {
                    Text(
                        text = "${feedJobs.size} " + if (language == AppLanguage.KANNADA) "ಪ್ರಕಟಣೆಗಳು" else "Updates",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // If not connected or empty, display EmptyJobsView ("Never invent government job notifications or results")
        if (feedJobs.isEmpty()) {
            item {
                EmptyJobsView(
                    hasConfiguredUrl = isBloggerConnected,
                    language = language,
                    onConnectBloggerClick = onOpenConnectDialog
                )
            }
        } else {
            items(feedJobs.take(10), key = { it.id }) { job ->
                val isSaved = savedJobs.any { it.id == job.id }
                JobCard(
                    job = job,
                    isSaved = isSaved,
                    language = language,
                    onJobClick = onJobClick,
                    onToggleSave = onToggleSave
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
