package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.CategoryType
import com.example.data.model.JobItem
import com.example.ui.components.EmptyJobsView
import com.example.ui.components.JobCard
import com.example.ui.theme.CleanWhite
import com.example.ui.theme.KarnatakaNavyBlue
import com.example.ui.theme.KarnatakaYellow
import com.example.ui.theme.KarnatakaYellowAmber
import com.example.ui.theme.TextDarkPrimary

@Composable
fun JobsListScreen(
    currentCategory: CategoryType,
    allJobs: List<JobItem>,
    savedJobs: List<JobItem>,
    isBloggerConnected: Boolean,
    language: AppLanguage,
    isLoading: Boolean,
    onCategoryChanged: (CategoryType) -> Unit,
    onJobClick: (JobItem) -> Unit,
    onToggleSave: (JobItem) -> Unit,
    onOpenConnectDialog: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredJobs = if (currentCategory == CategoryType.ALL) {
        allJobs
    } else {
        allJobs.filter { it.category == currentCategory }
    }

    val screenTitle = if (language == AppLanguage.KANNADA) currentCategory.kannadaName else currentCategory.englishName

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("jobs_list_screen")
    ) {
        // Top Filter Chips Row
        Surface(
            color = CleanWhite,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                // Header with Count & Refresh
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = screenTitle,
                            style = MaterialTheme.typography.titleLarge,
                            color = KarnatakaNavyBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(KarnatakaYellow, RoundedCornerShape(10.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${filteredJobs.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDarkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier.testTag("jobs_list_refresh_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = KarnatakaNavyBlue,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = KarnatakaNavyBlue
                            )
                        }
                    }
                }

                // Category Chips
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(CategoryType.values()) { category ->
                        val isSelected = category == currentCategory
                        val label = if (language == AppLanguage.KANNADA) category.kannadaName else category.englishName

                        FilterChip(
                            selected = isSelected,
                            onClick = { onCategoryChanged(category) },
                            label = {
                                Text(
                                    text = label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KarnatakaNavyBlue,
                                selectedLabelColor = CleanWhite,
                                containerColor = CleanWhite,
                                labelColor = KarnatakaNavyBlue
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = KarnatakaYellowAmber,
                                selectedBorderColor = KarnatakaNavyBlue
                            ),
                            modifier = Modifier.testTag("filter_chip_${category.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // Job Cards List
        if (filteredJobs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                EmptyJobsView(
                    hasConfiguredUrl = isBloggerConnected,
                    language = language,
                    onConnectBloggerClick = onOpenConnectDialog
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredJobs, key = { it.id }) { job ->
                    val isSaved = savedJobs.any { it.id == job.id }
                    JobCard(
                        job = job,
                        isSaved = isSaved,
                        language = language,
                        onJobClick = onJobClick,
                        onToggleSave = onToggleSave
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
