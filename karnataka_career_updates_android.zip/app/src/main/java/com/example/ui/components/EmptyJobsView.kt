package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.ui.theme.CleanWhite
import com.example.ui.theme.KarnatakaNavyBlue
import com.example.ui.theme.KarnatakaYellow
import com.example.ui.theme.TextDarkPrimary

@Composable
fun EmptyJobsView(
    hasConfiguredUrl: Boolean,
    language: AppLanguage,
    onConnectBloggerClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("empty_jobs_view"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CleanWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, KarnatakaNavyBlue.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(KarnatakaYellow.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (hasConfiguredUrl) Icons.Default.Info else Icons.Default.Language,
                    contentDescription = null,
                    tint = KarnatakaNavyBlue,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (hasConfiguredUrl) {
                    if (language == AppLanguage.KANNADA) "ಯಾವುದೇ ಹೊಸ ಪ್ರಕಟಣೆಗಳು ಲಭ್ಯವಿಲ್ಲ" else "No Notifications in This Section"
                } else {
                    AppStrings.notConnectedStatus(language)
                },
                style = MaterialTheme.typography.titleLarge,
                color = KarnatakaNavyBlue,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (hasConfiguredUrl) {
                    if (language == AppLanguage.KANNADA)
                        "ನಿಮ್ಮ ಬ್ಲಾಗರ್‌ನಲ್ಲಿ ಹೊಸ ಹುದ್ದೆಗಳ ಮಾಹಿತಿ ಪೋಸ್ಟ್ ಮಾಡಿದಾಗ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ."
                    else
                        "When new posts are published on your connected Blogger website, they will automatically appear here."
                } else {
                    AppStrings.emptyJobsWarning(language)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Trust badge: Never invent fake govt jobs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(KarnatakaYellow.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "Verified",
                    tint = KarnatakaNavyBlue,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (language == AppLanguage.KANNADA)
                        "ನೈಜತೆ ಖಾತರಿ: ನಕಲಿ ಉದ್ಯೋಗ ಪ್ರಕಟಣೆಗಳನ್ನು ತಡೆಯಲು ಬ್ಲಾಗರ್ ಸಂಪರ್ಕ ಅಗತ್ಯ."
                    else
                        "Authenticity Notice: Only genuine notifications from your blog are shown.",
                    style = MaterialTheme.typography.labelSmall,
                    color = KarnatakaNavyBlue,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onConnectBloggerClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("empty_view_connect_blogger_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = KarnatakaNavyBlue,
                    contentColor = CleanWhite
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = null,
                    tint = KarnatakaYellow,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (hasConfiguredUrl) AppStrings.changeUrlButton(language) else AppStrings.connectBloggerTitle(language),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
