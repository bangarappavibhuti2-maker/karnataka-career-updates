package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.CategoryType
import com.example.ui.components.BloggerConnectDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JobDetailScreen
import com.example.ui.screens.JobsListScreen
import com.example.ui.screens.SavedJobsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CleanWhite
import com.example.ui.theme.KarnatakaCareerTheme
import com.example.ui.theme.KarnatakaNavyBlue
import com.example.ui.theme.KarnatakaNavyDarkTheme
import com.example.ui.theme.KarnatakaYellow
import com.example.ui.theme.KarnatakaYellowAmber
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.viewmodel.JobViewModel

enum class AppNavScreen {
    HOME,
    JOBS,
    RESULTS,
    ADMIT_CARDS,
    EXAM_NOTIFICATIONS,
    SEARCH,
    SAVED,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    private val viewModel: JobViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KarnatakaCareerTheme {
                MainContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContent(viewModel: JobViewModel) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val bloggerUrl by viewModel.bloggerUrl.collectAsStateWithLifecycle()
    val blogInfo by viewModel.blogInfo.collectAsStateWithLifecycle()
    val feedJobs by viewModel.feedJobs.collectAsStateWithLifecycle()
    val savedJobs by viewModel.savedJobs.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val showConnectDialog by viewModel.showConnectDialog.collectAsStateWithLifecycle()
    val selectedJobDetail by viewModel.selectedJobDetail.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(AppNavScreen.HOME) }
    var currentCategoryFilter by remember { mutableStateOf(CategoryType.LATEST_JOBS) }

    // If detail screen is open, back clears detail first
    if (selectedJobDetail != null) {
        JobDetailScreen(
            job = selectedJobDetail!!,
            isSaved = savedJobs.any { it.id == selectedJobDetail!!.id },
            language = language,
            onBack = { viewModel.clearJobDetail() },
            onToggleSave = { viewModel.toggleSaveJob(it) }
        )
        return
    }

    // Top-level back handler
    BackHandler(enabled = currentScreen != AppNavScreen.HOME) {
        currentScreen = AppNavScreen.HOME
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = AppStrings.appTitle(language),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = CleanWhite
                        )
                        Text(
                            text = if (language == AppLanguage.KANNADA) "ಸರ್ಕಾರಿ ಉದ್ಯೋಗ & ಫಲಿತಾಂಶ" else "Govt Jobs & Results",
                            style = MaterialTheme.typography.labelSmall,
                            color = KarnatakaYellow
                        )
                    }
                },
                actions = {
                    // Language Switcher Button (Large, prominent toggle: EN <-> ಕನ್ನಡ)
                    Surface(
                        onClick = { viewModel.toggleLanguage() },
                        shape = RoundedCornerShape(20.dp),
                        color = KarnatakaYellow,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .testTag("top_bar_language_toggle_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = KarnatakaNavyBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (language == AppLanguage.ENGLISH) "ಕನ್ನಡ" else "ENG",
                                style = MaterialTheme.typography.labelMedium,
                                color = KarnatakaNavyBlue,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    // Search Shortcut
                    IconButton(
                        onClick = { currentScreen = AppNavScreen.SEARCH },
                        modifier = Modifier.testTag("top_bar_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = CleanWhite
                        )
                    }

                    // Blogger Setup Shortcut
                    IconButton(
                        onClick = { viewModel.openConnectDialog() },
                        modifier = Modifier.testTag("top_bar_connect_blogger_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = "Blogger",
                            tint = if (bloggerUrl.isNotBlank()) KarnatakaYellow else CleanWhite
                        )
                    }

                    // Settings Shortcut
                    IconButton(
                        onClick = { currentScreen = AppNavScreen.SETTINGS },
                        modifier = Modifier.testTag("top_bar_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = CleanWhite
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = KarnatakaNavyBlue,
                    titleContentColor = CleanWhite
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CleanWhite,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                // Home
                NavigationBarItem(
                    selected = currentScreen == AppNavScreen.HOME,
                    onClick = { currentScreen = AppNavScreen.HOME },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text(AppStrings.homeTab(language), fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarnatakaNavyBlue,
                        selectedTextColor = KarnatakaNavyBlue,
                        indicatorColor = KarnatakaYellow.copy(alpha = 0.35f),
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_item_home")
                )

                // Govt Jobs
                NavigationBarItem(
                    selected = currentScreen == AppNavScreen.JOBS,
                    onClick = {
                        currentCategoryFilter = CategoryType.LATEST_JOBS
                        currentScreen = AppNavScreen.JOBS
                    },
                    icon = { Icon(Icons.Default.Work, contentDescription = "Jobs") },
                    label = { Text(AppStrings.latestJobsTab(language), fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarnatakaNavyBlue,
                        selectedTextColor = KarnatakaNavyBlue,
                        indicatorColor = KarnatakaYellow.copy(alpha = 0.35f),
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_item_jobs")
                )

                // Results
                NavigationBarItem(
                    selected = currentScreen == AppNavScreen.RESULTS,
                    onClick = {
                        currentCategoryFilter = CategoryType.RESULTS
                        currentScreen = AppNavScreen.RESULTS
                    },
                    icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Results") },
                    label = { Text(AppStrings.resultsTab(language), fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarnatakaNavyBlue,
                        selectedTextColor = KarnatakaNavyBlue,
                        indicatorColor = KarnatakaYellow.copy(alpha = 0.35f),
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_item_results")
                )

                // Admit Cards
                NavigationBarItem(
                    selected = currentScreen == AppNavScreen.ADMIT_CARDS,
                    onClick = {
                        currentCategoryFilter = CategoryType.ADMIT_CARDS
                        currentScreen = AppNavScreen.ADMIT_CARDS
                    },
                    icon = { Icon(Icons.Default.Badge, contentDescription = "Admit Cards") },
                    label = { Text(AppStrings.admitCardsTab(language), fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarnatakaNavyBlue,
                        selectedTextColor = KarnatakaNavyBlue,
                        indicatorColor = KarnatakaYellow.copy(alpha = 0.35f),
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_item_admit_cards")
                )

                // Saved Jobs
                NavigationBarItem(
                    selected = currentScreen == AppNavScreen.SAVED,
                    onClick = { currentScreen = AppNavScreen.SAVED },
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = "Saved") },
                    label = { Text(AppStrings.savedJobsTab(language), fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarnatakaNavyBlue,
                        selectedTextColor = KarnatakaNavyBlue,
                        indicatorColor = KarnatakaYellow.copy(alpha = 0.35f),
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("nav_item_saved")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppNavScreen.HOME -> {
                    HomeScreen(
                        bloggerUrl = bloggerUrl,
                        blogInfo = blogInfo,
                        language = language,
                        feedJobs = feedJobs,
                        savedJobs = savedJobs,
                        isLoading = isLoading,
                        onNavigateCategory = { cat ->
                            currentCategoryFilter = cat
                            when (cat) {
                                CategoryType.LATEST_JOBS -> currentScreen = AppNavScreen.JOBS
                                CategoryType.RESULTS -> currentScreen = AppNavScreen.RESULTS
                                CategoryType.ADMIT_CARDS -> currentScreen = AppNavScreen.ADMIT_CARDS
                                CategoryType.EXAM_NOTIFICATIONS -> currentScreen = AppNavScreen.EXAM_NOTIFICATIONS
                                CategoryType.ALL -> currentScreen = AppNavScreen.JOBS
                            }
                        },
                        onNavigateSearch = { currentScreen = AppNavScreen.SEARCH },
                        onNavigateSaved = { currentScreen = AppNavScreen.SAVED },
                        onJobClick = { viewModel.selectJobDetail(it) },
                        onToggleSave = { viewModel.toggleSaveJob(it) },
                        onOpenConnectDialog = { viewModel.openConnectDialog() },
                        onRefresh = { viewModel.refresh() }
                    )
                }

                AppNavScreen.JOBS,
                AppNavScreen.RESULTS,
                AppNavScreen.ADMIT_CARDS,
                AppNavScreen.EXAM_NOTIFICATIONS -> {
                    JobsListScreen(
                        currentCategory = currentCategoryFilter,
                        allJobs = feedJobs,
                        savedJobs = savedJobs,
                        isBloggerConnected = bloggerUrl.isNotBlank(),
                        language = language,
                        isLoading = isLoading,
                        onCategoryChanged = { cat ->
                            currentCategoryFilter = cat
                        },
                        onJobClick = { viewModel.selectJobDetail(it) },
                        onToggleSave = { viewModel.toggleSaveJob(it) },
                        onOpenConnectDialog = { viewModel.openConnectDialog() },
                        onRefresh = { viewModel.refresh() }
                    )
                }

                AppNavScreen.SEARCH -> {
                    SearchScreen(
                        searchQuery = searchQuery,
                        searchResults = searchResults,
                        savedJobs = savedJobs,
                        language = language,
                        onQueryChange = { viewModel.setSearchQuery(it) },
                        onJobClick = { viewModel.selectJobDetail(it) },
                        onToggleSave = { viewModel.toggleSaveJob(it) }
                    )
                }

                AppNavScreen.SAVED -> {
                    SavedJobsScreen(
                        savedJobs = savedJobs,
                        language = language,
                        onJobClick = { viewModel.selectJobDetail(it) },
                        onToggleSave = { viewModel.toggleSaveJob(it) }
                    )
                }

                AppNavScreen.SETTINGS -> {
                    SettingsScreen(
                        bloggerUrl = bloggerUrl,
                        blogInfo = blogInfo,
                        language = language,
                        onLanguageChange = { viewModel.setLanguage(it) },
                        onOpenConnectDialog = { viewModel.openConnectDialog() },
                        onDisconnectBlogger = { viewModel.disconnectBlogger() },
                        onRefresh = { viewModel.refresh() }
                    )
                }
            }
        }
    }

    // Modal dialog to connect Blogger URL
    if (showConnectDialog) {
        BloggerConnectDialog(
            initialUrl = bloggerUrl,
            language = language,
            onDismiss = { viewModel.closeConnectDialog() },
            onConnect = { url, callback ->
                viewModel.connectBlogger(url, callback)
            }
        )
    }
}
