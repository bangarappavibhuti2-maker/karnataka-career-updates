package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_jobs")
data class JobEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val summary: String,
    val contentHtml: String,
    val originalUrl: String,
    val category: String,
    val publishedDate: String,
    val thumbnailUrl: String?,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)
