package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.AppDatabase
import com.example.data.local.JobDao
import com.example.data.model.AppLanguage
import com.example.data.model.CategoryType
import com.example.data.model.JobItem
import com.example.data.remote.BloggerBlogInfo
import com.example.data.remote.BloggerFeedService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

class JobRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("karnataka_career_prefs", Context.MODE_PRIVATE)
    private val jobDao: JobDao = AppDatabase.getInstance(context).jobDao()
    private val feedService = BloggerFeedService()

    private val _bloggerUrl = MutableStateFlow(prefs.getString("blogger_url", "") ?: "")
    val bloggerUrl = _bloggerUrl.asStateFlow()

    private val _blogInfo = MutableStateFlow<BloggerBlogInfo?>(null)
    val blogInfo = _blogInfo.asStateFlow()

    private val _language = MutableStateFlow(AppLanguage.fromCode(prefs.getString("app_lang", "en") ?: "en"))
    val language = _language.asStateFlow()

    private val _feedJobs = MutableStateFlow<List<JobItem>>(emptyList())
    val feedJobs = _feedJobs.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage = _errorMessage.asStateFlow()

    val savedJobs: Flow<List<JobItem>> = jobDao.getAllSavedJobs().map { entities ->
        entities.map { JobItem.fromEntity(it) }
    }

    fun isJobSaved(jobId: String): Flow<Boolean> = jobDao.isJobSaved(jobId)

    fun setLanguage(lang: AppLanguage) {
        prefs.edit().putString("app_lang", lang.code).apply()
        _language.value = lang
    }

    suspend fun saveBloggerUrl(url: String): Result<BloggerBlogInfo> {
        val normalized = feedService.normalizeUrl(url)
        if (normalized.isBlank()) {
            return Result.failure(IllegalArgumentException("Please enter a Blogger website URL"))
        }

        _isLoading.value = true
        _errorMessage.value = null

        val infoResult = feedService.verifyAndFetchBlogInfo(normalized)
        if (infoResult.isSuccess) {
            val info = infoResult.getOrThrow()
            prefs.edit()
                .putString("blogger_url", normalized)
                .putString("blog_title", info.title)
                .apply()
            _bloggerUrl.value = normalized
            _blogInfo.value = info
            // Immediately fetch posts from the connected blog
            refreshFeed()
        } else {
            _isLoading.value = false
            _errorMessage.value = infoResult.exceptionOrNull()?.message ?: "Unable to connect to Blogger URL"
        }
        return infoResult
    }

    fun disconnectBlogger() {
        prefs.edit().remove("blogger_url").remove("blog_title").apply()
        _bloggerUrl.value = ""
        _blogInfo.value = null
        _feedJobs.value = emptyList()
    }

    suspend fun refreshFeed(): Result<List<JobItem>> {
        val currentUrl = _bloggerUrl.value
        if (currentUrl.isBlank()) {
            _feedJobs.value = emptyList()
            return Result.success(emptyList())
        }

        _isLoading.value = true
        _errorMessage.value = null

        val result = feedService.fetchPosts(currentUrl, maxResults = 50)
        _isLoading.value = false

        if (result.isSuccess) {
            val list = result.getOrThrow()
            _feedJobs.value = list
            _errorMessage.value = null
        } else {
            _errorMessage.value = result.exceptionOrNull()?.message ?: "Failed to fetch posts from Blogger"
        }
        return result
    }

    suspend fun toggleSaveJob(job: JobItem) {
        val isCurrentlySaved = jobDao.getJobById(job.id) != null
        if (isCurrentlySaved) {
            jobDao.deleteJobById(job.id)
        } else {
            jobDao.insertJob(job.toEntity())
        }
    }

    suspend fun deleteSavedJob(jobId: String) {
        jobDao.deleteJobById(jobId)
    }

    fun getJobsByCategory(category: CategoryType): List<JobItem> {
        if (category == CategoryType.ALL) return _feedJobs.value
        return _feedJobs.value.filter { it.category == category }
    }

    fun searchJobs(query: String, category: CategoryType = CategoryType.ALL): List<JobItem> {
        val baseList = if (category == CategoryType.ALL) _feedJobs.value else _feedJobs.value.filter { it.category == category }
        if (query.isBlank()) return baseList

        val trimmed = query.trim().lowercase()
        return baseList.filter { item ->
            item.title.lowercase().contains(trimmed) ||
            item.summary.lowercase().contains(trimmed) ||
            item.tags.any { it.lowercase().contains(trimmed) }
        }
    }
}
