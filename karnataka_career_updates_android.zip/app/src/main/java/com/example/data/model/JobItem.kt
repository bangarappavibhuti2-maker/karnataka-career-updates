package com.example.data.model

import com.example.data.local.JobEntity

enum class CategoryType(
    val englishName: String,
    val kannadaName: String,
    val iconKey: String
) {
    ALL("All Updates", "ಎಲ್ಲಾ ಪ್ರಕಟಣೆಗಳು", "all"),
    LATEST_JOBS("Govt Jobs", "ಸರ್ಕಾರಿ ಉದ್ಯೋಗಗಳು", "jobs"),
    RESULTS("Results", "ಫಲಿತಾಂಶಗಳು", "results"),
    ADMIT_CARDS("Admit Cards", "ಪ್ರವೇಶ ಪತ್ರ / ಹಾಲ್ ಟಿಕೆಟ್", "admit_cards"),
    EXAM_NOTIFICATIONS("Exam Alerts", "ಪರೀಕ್ಷಾ ಅಧಿಸೂಚನೆಗಳು", "exams")
}

data class JobItem(
    val id: String,
    val title: String,
    val summary: String,
    val contentHtml: String,
    val originalUrl: String,
    val category: CategoryType,
    val publishedDate: String,
    val thumbnailUrl: String? = null,
    val tags: List<String> = emptyList(),
    val isSaved: Boolean = false
) {
    fun toEntity(): JobEntity {
        return JobEntity(
            id = id,
            title = title,
            summary = summary,
            contentHtml = contentHtml,
            originalUrl = originalUrl,
            category = category.name,
            publishedDate = publishedDate,
            thumbnailUrl = thumbnailUrl
        )
    }

    companion object {
        fun fromEntity(entity: JobEntity): JobItem {
            val cat = try {
                CategoryType.valueOf(entity.category)
            } catch (e: Exception) {
                CategoryType.LATEST_JOBS
            }
            return JobItem(
                id = entity.id,
                title = entity.title,
                summary = entity.summary,
                contentHtml = entity.contentHtml,
                originalUrl = entity.originalUrl,
                category = cat,
                publishedDate = entity.publishedDate,
                thumbnailUrl = entity.thumbnailUrl,
                isSaved = true
            )
        }
    }
}
