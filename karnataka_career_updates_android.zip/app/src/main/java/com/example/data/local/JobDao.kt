package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface JobDao {
    @Query("SELECT * FROM saved_jobs ORDER BY savedAtTimestamp DESC")
    fun getAllSavedJobs(): Flow<List<JobEntity>>

    @Query("SELECT * FROM saved_jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJobById(jobId: String): JobEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM saved_jobs WHERE id = :jobId)")
    fun isJobSaved(jobId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJob(job: JobEntity)

    @Delete
    suspend fun deleteJob(job: JobEntity)

    @Query("DELETE FROM saved_jobs WHERE id = :jobId")
    suspend fun deleteJobById(jobId: String)
}
