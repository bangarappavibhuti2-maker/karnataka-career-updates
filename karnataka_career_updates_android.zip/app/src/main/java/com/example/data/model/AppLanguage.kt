package com.example.data.model

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    KANNADA("kn", "ಕನ್ನಡ");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return if (code == "kn") KANNADA else ENGLISH
        }
    }
}

object AppStrings {
    // Top Bar & Branding
    fun appTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Karnataka Career Updates"
        AppLanguage.KANNADA -> "ಕರ್ನಾಟಕ ವೃತ್ತಿ ಮಾಹಿತಿ"
    }

    fun appSubtitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Official Jobs, Results & Admit Cards"
        AppLanguage.KANNADA -> "ಸರ್ಕಾರಿ ಹುದ್ದೆಗಳು, ಫಲಿತಾಂಶ & ಪ್ರವೇಶ ಪತ್ರ"
    }

    // Tabs
    fun homeTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Home"
        AppLanguage.KANNADA -> "ಮುಖಪುಟ"
    }

    fun latestJobsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Govt Jobs"
        AppLanguage.KANNADA -> "ಉದ್ಯೋಗಗಳು"
    }

    fun resultsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Results"
        AppLanguage.KANNADA -> "ಫಲಿತಾಂಶ"
    }

    fun admitCardsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Admit Cards"
        AppLanguage.KANNADA -> "ಪ್ರವೇಶ ಪತ್ರ"
    }

    fun examNotificationsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Exam Alerts"
        AppLanguage.KANNADA -> "ಪರೀಕ್ಷಾ ವಿವರ"
    }

    fun searchTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Search"
        AppLanguage.KANNADA -> "ಹುಡುಕಿ"
    }

    fun savedJobsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Saved"
        AppLanguage.KANNADA -> "ಉಳಿಸಿದವು"
    }

    fun settingsTab(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Settings"
        AppLanguage.KANNADA -> "ಸೆಟ್ಟಿಂಗ್ಸ್"
    }

    // Connect Blogger Banner & Dialog
    fun connectBloggerTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Connect Your Blogger Website"
        AppLanguage.KANNADA -> "ನಿಮ್ಮ ಬ್ಲಾಗರ್ ವೆಬ್‌ಸೈಟ್ ಲಿಂಕ್ ಮಾಡಿ"
    }

    fun connectBloggerDesc(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Enter your Blogger website address to stream live Karnataka government job notifications, admit cards, and results. We never invent or fabricate notifications."
        AppLanguage.KANNADA -> "ನಿಮ್ಮ ಬ್ಲಾಗರ್ ವೆಬ್‌ಸೈಟ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ. ಯಾವುದೇ ನಕಲಿ ಅಥವಾ ಕಲ್ಪಿತ ಮಾಹಿತಿಯನ್ನು ನೀಡದೆ, ನೈಜ ಸರ್ಕಾರಿ ಉದ್ಯೋಗ ಪ್ರಕಟಣೆಗಳನ್ನು ತಲುಪಿಸಲಾಗುತ್ತದೆ."
    }

    fun bloggerUrlHint(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "e.g., https://yourname.blogspot.com"
        AppLanguage.KANNADA -> "ಉದಾ: https://yourname.blogspot.com"
    }

    fun connectButton(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Connect & Load Feed"
        AppLanguage.KANNADA -> "ಸಂಪರ್ಕಿಸಿ & ಲೋಡ್ ಮಾಡಿ"
    }

    fun connectedStatus(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Connected to Blogger"
        AppLanguage.KANNADA -> "ಬ್ಲಾಗರ್‌ಗೆ ಸಂಪರ್ಕಿಸಲಾಗಿದೆ"
    }

    fun notConnectedStatus(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "No Blogger Website Connected"
        AppLanguage.KANNADA -> "ಯಾವುದೇ ಬ್ಲಾಗರ್ ಸಂಪರ್ಕಗೊಂಡಿಲ್ಲ"
    }

    fun changeUrlButton(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Change Blogger URL"
        AppLanguage.KANNADA -> "ಬ್ಲಾಗರ್ ಲಿಂಕ್ ಬದಲಿಸಿ"
    }

    // Action buttons
    fun readDetails(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "View Details"
        AppLanguage.KANNADA -> "ಸಂಪೂರ್ಣ ವಿವರ ನೋಡಿ"
    }

    fun openWebsite(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Open in Blogger Website"
        AppLanguage.KANNADA -> "ಬ್ಲಾಗರ್ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಓದಿ"
    }

    fun sharePost(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Share Update"
        AppLanguage.KANNADA -> "ಹಂಚಿಕೊಳ್ಳಿ"
    }

    fun saveJob(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Save for Later"
        AppLanguage.KANNADA -> "ಉಳಿಸಿ"
    }

    fun removeSaved(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Saved (Tap to remove)"
        AppLanguage.KANNADA -> "ಉಳಿಸಲಾಗಿದೆ (ತೆಗೆದುಹಾಕಲು ಒತ್ತಿ)"
    }

    fun searchPlaceholder(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Search jobs, KPSC, KEA, Police, FDA..."
        AppLanguage.KANNADA -> "ಹುದ್ದೆಗಳು, KPSC, KEA, ಪೊಲೀಸ್ ಹುಡುಕಿ..."
    }

    // Section Titles
    fun quickCategoriesTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Career Categories"
        AppLanguage.KANNADA -> "ಉದ್ಯೋಗ ವಿಭಾಗಗಳು"
    }

    fun recentUpdatesTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Recent Karnataka Updates"
        AppLanguage.KANNADA -> "ಇತ್ತೀಚಿನ ಪ್ರಕಟಣೆಗಳು"
    }

    fun emptyJobsWarning(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Please connect your Blogger website to view official Karnataka updates. In accordance with policy, we never generate or invent government notifications."
        AppLanguage.KANNADA -> "ನೈಜ ಪ್ರಕಟಣೆಗಳನ್ನು ವೀಕ್ಷಿಸಲು ನಿಮ್ಮ ಬ್ಲಾಗರ್ ಸೈಟ್ ಲಿಂಕ್ ಮಾಡಿ. ನಾವು ಯಾವುದೇ ನಕಲಿ ಅಥವಾ ಕೃತಕ ಸರ್ಕಾರಿ ಉದ್ಯೋಗ ಪ್ರಕಟಣೆಗಳನ್ನು ಸೃಷ್ಟಿಸುವುದಿಲ್ಲ."
    }

    fun refresh(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "Refresh"
        AppLanguage.KANNADA -> "ನವೀಕರಿಸಿ"
    }

    fun noResultsFound(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "No matching career updates found"
        AppLanguage.KANNADA -> "ಯಾವುದೇ ಹೊಂದಾಣಿಕೆಯ ಪ್ರಕಟಣೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ"
    }

    fun noSavedJobs(lang: AppLanguage) = when (lang) {
        AppLanguage.ENGLISH -> "No saved updates yet. Bookmark important jobs to review them anytime."
        AppLanguage.KANNADA -> "ಯಾವುದೇ ಹುದ್ದೆಗಳನ್ನು ಉಳಿಸಿಲ್ಲ. ಪ್ರಮುಖ ಉದ್ಯೋಗಗಳನ್ನು ನಂತರ ನೋಡಲು ಬುಕ್‌ಮಾರ್ಕ್ ಮಾಡಿ."
    }
}
