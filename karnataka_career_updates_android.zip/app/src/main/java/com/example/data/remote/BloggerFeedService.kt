package com.example.data.remote

import androidx.core.text.HtmlCompat
import com.example.data.model.CategoryType
import com.example.data.model.JobItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class BloggerBlogInfo(
    val title: String,
    val subtitle: String,
    val blogUrl: String,
    val totalPosts: Int
)

class BloggerFeedService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    fun normalizeUrl(rawUrl: String): String {
        var trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) return ""
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
            trimmed = "https://$trimmed"
        } else if (trimmed.startsWith("http://")) {
            trimmed = trimmed.replaceFirst("http://", "https://")
        }
        return trimmed.trimEnd('/')
    }

    suspend fun verifyAndFetchBlogInfo(rawUrl: String): Result<BloggerBlogInfo> = withContext(Dispatchers.IO) {
        try {
            val normalized = normalizeUrl(rawUrl)
            if (normalized.isEmpty()) {
                return@withContext Result.failure(IllegalArgumentException("Please enter a valid Blogger URL"))
            }

            val feedUrl = "$normalized/feeds/posts/default?alt=json&max-results=1"
            val request = Request.Builder()
                .url(feedUrl)
                .header("User-Agent", "KarnatakaCareerUpdatesApp/1.0 (Android)")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(
                    Exception("Failed to reach Blogger feed (HTTP ${response.code}). Ensure blog is public and URL is correct.")
                )
            }

            val bodyString = response.body?.string() ?: ""
            val json = JSONObject(bodyString)
            val feedObj = json.getJSONObject("feed")

            val title = feedObj.optJSONObject("title")?.optString("\$t") ?: "Karnataka Career Blog"
            val subtitle = feedObj.optJSONObject("subtitle")?.optString("\$t") ?: ""
            val totalResults = feedObj.optJSONObject("openSearch\$totalResults")?.optString("\$t")?.toIntOrNull() ?: 0

            Result.success(
                BloggerBlogInfo(
                    title = title,
                    subtitle = subtitle,
                    blogUrl = normalized,
                    totalPosts = totalResults
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchPosts(rawUrl: String, maxResults: Int = 50): Result<List<JobItem>> = withContext(Dispatchers.IO) {
        try {
            val normalized = normalizeUrl(rawUrl)
            if (normalized.isEmpty()) {
                return@withContext Result.failure(IllegalArgumentException("Blogger URL is empty"))
            }

            val feedUrl = "$normalized/feeds/posts/default?alt=json&max-results=$maxResults"
            val request = Request.Builder()
                .url(feedUrl)
                .header("User-Agent", "KarnatakaCareerUpdatesApp/1.0 (Android)")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Blogger feed error: HTTP ${response.code}"))
            }

            val bodyString = response.body?.string() ?: ""
            val json = JSONObject(bodyString)
            val feedObj = json.getJSONObject("feed")
            val entriesArray = feedObj.optJSONArray("entry") ?: JSONArray()

            val posts = mutableListOf<JobItem>()
            for (i in 0 until entriesArray.length()) {
                val entry = entriesArray.getJSONObject(i)
                val post = parseEntry(entry, normalized)
                if (post != null) {
                    posts.add(post)
                }
            }

            Result.success(posts)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseEntry(entry: JSONObject, blogBaseUrl: String): JobItem? {
        val id = entry.optJSONObject("id")?.optString("\$t") ?: return null
        val title = entry.optJSONObject("title")?.optString("\$t")?.trim() ?: "Career Notification"

        val contentObj = entry.optJSONObject("content")
        val summaryObj = entry.optJSONObject("summary")
        val contentHtml = contentObj?.optString("\$t") ?: summaryObj?.optString("\$t") ?: ""

        val rawSummary = if (summaryObj != null) {
            summaryObj.optString("\$t")
        } else {
            contentHtml
        }
        val cleanSummary = extractCleanSummary(rawSummary)

        // Find alternate link (the web post URL)
        var postUrl = blogBaseUrl
        val links = entry.optJSONArray("link")
        if (links != null) {
            for (j in 0 until links.length()) {
                val l = links.getJSONObject(j)
                if (l.optString("rel") == "alternate" && l.optString("type") == "text/html") {
                    postUrl = l.optString("href")
                    break
                }
            }
        }

        // Thumbnail extraction: first try media$thumbnail, else regex parse from html
        var thumbnailUrl: String? = entry.optJSONObject("media\$thumbnail")?.optString("url")
        if (thumbnailUrl.isNullOrEmpty() && contentHtml.isNotEmpty()) {
            thumbnailUrl = extractFirstImageSrc(contentHtml)
        }
        // Upgrade Blogger thumbnail size if it's s72-c to high res
        if (thumbnailUrl != null && thumbnailUrl.contains("/s72-c/")) {
            thumbnailUrl = thumbnailUrl.replace("/s72-c/", "/w640-h360-p-k-no-nu/")
        }

        // Tags / Categories
        val tagsList = mutableListOf<String>()
        val catArray = entry.optJSONArray("category")
        if (catArray != null) {
            for (k in 0 until catArray.length()) {
                val catObj = catArray.getJSONObject(k)
                val term = catObj.optString("term").trim()
                if (term.isNotEmpty()) {
                    tagsList.add(term)
                }
            }
        }

        val publishedRaw = entry.optJSONObject("published")?.optString("\$t") ?: ""
        val formattedDate = formatIsoDate(publishedRaw)

        val categoryType = classifyPost(title, tagsList, cleanSummary)

        return JobItem(
            id = id,
            title = title,
            summary = cleanSummary,
            contentHtml = contentHtml,
            originalUrl = postUrl,
            category = categoryType,
            publishedDate = formattedDate,
            thumbnailUrl = thumbnailUrl,
            tags = tagsList
        )
    }

    private fun classifyPost(title: String, tags: List<String>, summary: String): CategoryType {
        val lowerText = (title + " " + tags.joinToString(" ") + " " + summary).lowercase(Locale.ROOT)

        // 1. Results / Cut-off
        if (lowerText.contains("result") || lowerText.contains("ಫಲಿತಾಂಶ") ||
            lowerText.contains("cut off") || lowerText.contains("cutoff") ||
            lowerText.contains("merit list") || lowerText.contains("selection list") ||
            lowerText.contains("ಅಂಕಪಟ್ಟಿ") || lowerText.contains("marks list")
        ) {
            return CategoryType.RESULTS
        }

        // 2. Admit Card / Hall Ticket
        if (lowerText.contains("admit card") || lowerText.contains("hall ticket") ||
            lowerText.contains("call letter") || lowerText.contains("ಪ್ರವೇಶ ಪತ್ರ") ||
            lowerText.contains("ಹಾಲ್ ಟಿಕೆಟ್") || lowerText.contains("admission ticket")
        ) {
            return CategoryType.ADMIT_CARDS
        }

        // 3. Exam Notifications / Time table
        if (lowerText.contains("exam date") || lowerText.contains("time table") ||
            lowerText.contains("timetable") || lowerText.contains("syllabus") ||
            lowerText.contains("ಪರೀಕ್ಷಾ ದಿನಾಂಕ") || lowerText.contains("ವೇಳಾಪಟ್ಟಿ") ||
            lowerText.contains("exam notice") || lowerText.contains("key answer") ||
            lowerText.contains("answer key") || lowerText.contains("ಉತ್ತರ ಕೀಲಿ")
        ) {
            return CategoryType.EXAM_NOTIFICATIONS
        }

        // Default to Latest Jobs
        return CategoryType.LATEST_JOBS
    }

    private fun extractCleanSummary(html: String): String {
        if (html.isBlank()) return ""
        val plainText = HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_LEGACY).toString().trim()
        val singleSpaced = plainText.replace(Regex("\\s+"), " ")
        return if (singleSpaced.length > 200) {
            singleSpaced.substring(0, 197) + "..."
        } else {
            singleSpaced
        }
    }

    private fun extractFirstImageSrc(html: String): String? {
        val pattern = Pattern.compile("<img[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(html)
        return if (matcher.find()) {
            matcher.group(1)
        } else {
            null
        }
    }

    private fun formatIsoDate(iso: String): String {
        if (iso.isBlank()) return "Recently"
        return try {
            // ISO format e.g. 2026-10-10T14:30:00.000+05:30
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH)
            val parsed = parser.parse(iso.substring(0, minOf(19, iso.length)))
            if (parsed != null) {
                val formatter = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
                formatter.format(parsed)
            } else {
                iso.take(10)
            }
        } catch (e: Exception) {
            iso.take(10)
        }
    }
}
