package com.example

import com.example.data.model.AppLanguage
import com.example.data.model.CategoryType
import com.example.data.model.JobItem
import com.example.data.remote.BloggerFeedService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testUrlNormalization() {
        val service = BloggerFeedService()
        assertEquals("https://karnatakacareers.blogspot.com", service.normalizeUrl("karnatakacareers.blogspot.com"))
        assertEquals("https://karnatakacareers.blogspot.com", service.normalizeUrl("http://karnatakacareers.blogspot.com/"))
        assertEquals("https://karnatakacareers.blogspot.com", service.normalizeUrl("https://karnatakacareers.blogspot.com/"))
    }

    @Test
    fun testJobItemEntityMapping() {
        val job = JobItem(
            id = "tag:blogger.com,post-1",
            title = "KPSC FDA Recruitment 2026",
            summary = "Karnataka Public Service Commission has released FDA notification",
            contentHtml = "<p>Full details</p>",
            originalUrl = "https://example.blogspot.com/2026/10/kpsc-fda.html",
            category = CategoryType.LATEST_JOBS,
            publishedDate = "12 Oct 2026",
            thumbnailUrl = "https://example.com/img.jpg",
            tags = listOf("KPSC", "Govt Jobs"),
            isSaved = false
        )

        val entity = job.toEntity()
        val restored = JobItem.fromEntity(entity)

        assertEquals(job.id, restored.id)
        assertEquals(job.title, restored.title)
        assertEquals(job.category, restored.category)
        assertTrue(restored.isSaved)
    }

    @Test
    fun testLanguageToggle() {
        val kn = AppLanguage.fromCode("kn")
        val en = AppLanguage.fromCode("en")

        assertEquals(AppLanguage.KANNADA, kn)
        assertEquals(AppLanguage.ENGLISH, en)
    }
}
